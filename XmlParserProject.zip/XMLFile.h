#ifndef XMLFILE_H
#define XMLFILE_H
#include<fstream>
#include<string>
#include"XMLElement.h"
using std::ifstream;
using std::ofstream;
using std::string;

class XMLFile{
    string path;
    XMLElement* root;

public:
    XMLFile(){
        path = "";
        root = nullptr;
    }
  
    void openFile(string _path){
        path = _path;
        ifstream in(path.c_str());

        cout << "Ifstream made!\n";

        char currentSymbol = 'A';

        currentSymbol = in.get();
        cout << "currentSymbol: '" << currentSymbol << "'\n";

        return;

        int i = 0;

        while(i < 8 && !in.eof()){

            cout << "In while(!in.eof())\n";

            in >> currentSymbol;

            cout << "currentSymbol: '" << currentSymbol << "'\n";

            /*
            if(currentSymbol == '<'){
                string currentTagName;
                in >> currentTagName;
                root = new XMLElement(currentTagName);

                in >> currentSymbol;

                while(currentSymbol != '>'){

                    cout << "In while(currentSymbol != '>')\n";

                    string attributeKey;
                    getline(in, attributeKey, '=');     //Read attributeKey till =
                    in.ignore();                        //Ignore one "
                    
                    string attributeValue;
                    getline(in, attributeValue, '"' );
                    
                    Attribute newAttribute(attributeKey, attributeValue);
                    root->addAttribute(newAttribute);

                    in >> currentSymbol;

                    cout << "+";
                }

                cout << "Closing the tag...\n";
            }
            */

            i++;
        }

        cout << "Printing the element...\n";
        root->printElement();
    } 
    
    void closeFile(){
        path = "";
        //TODO
        root = nullptr;
    }   
};

#endif